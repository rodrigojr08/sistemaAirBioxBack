require('dotenv').config();
console.log("JWT_SECRET:", process.env.JWT_SECRET);